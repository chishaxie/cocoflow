#include "shared.h"

const char kSharedStr[] = "shared.c";
