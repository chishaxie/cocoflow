#include <stdio.h>

void common(void)
{
  printf("hello from common.c\n");
  return;
}
