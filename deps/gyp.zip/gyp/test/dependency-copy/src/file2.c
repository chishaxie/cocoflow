#include <stdio.h>

int main(int argc, char *argv[])
{
  printf("Hello from file2.c\n");
  return 0;
}
