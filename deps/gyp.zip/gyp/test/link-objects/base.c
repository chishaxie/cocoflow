void extra();

int main(int argc, char** argv) {
  extra();
  return 0;
}
