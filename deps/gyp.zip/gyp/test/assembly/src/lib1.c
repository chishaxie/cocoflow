int lib1_function(void) {
  return 42;
}
